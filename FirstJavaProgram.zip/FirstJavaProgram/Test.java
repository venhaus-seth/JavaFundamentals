public class Test {
    public static void main(String[] args) {
        System.out.println("My Name is Seth");
        System.out.println("I am 100 years old");
        System.out.println("My hometown is Seattle, WA");
    }
}